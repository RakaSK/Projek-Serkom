package id.ac.uns.vokasi.d3ti.gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import id.ac.uns.vokasi.d3ti.jdbc.*;

public class TampilanDatabase extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private MahasiswaData mahasiswaData;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TampilanDatabase frame = new TampilanDatabase();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TampilanDatabase() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 823, 568);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 96, 787, 410);
		contentPane.add(scrollPane);
		String[] columnName= {"NIM","Nama","Email","Password","Gender"};
		DefaultTableModel dtm=new DefaultTableModel();
		dtm.setColumnIdentifiers(columnName);
		
		mahasiswaData=new MahasiswaData();
		ArrayList<MahasiswaModel> dataMahasiswa=new ArrayList<>();
		dataMahasiswa=mahasiswaData.getData();
		for(int i=0;i<dataMahasiswa.size();i++) {
			ArrayList<Object> tempMhs=new ArrayList<>();
			tempMhs.add(dataMahasiswa.get(i).getNim());
			tempMhs.add(dataMahasiswa.get(i).getNama());
			tempMhs.add(dataMahasiswa.get(i).getJK());
			tempMhs.add(dataMahasiswa.get(i).getTmpLahir());
			tempMhs.add(dataMahasiswa.get(i).getTglLahir());
			tempMhs.add(dataMahasiswa.get(i).getAlamat());
			dtm.addRow(tempMhs.toArray());
		}
		
		
		table = new JTable(dtm);
		scrollPane.setViewportView(table);
	}
}
