package id.ac.uns.vokasi.d3ti.jdbc;

public class Mahasiswa {
	
	public static void main(String[] ar) {
		
		MahasiswaData mahasiswaData = new MahasiswaData();

		System.out.println("Database Baris Ke-1");
		
			System.out.println("NIM = "+mahasiswaData.getData().get(0).getNim());
			System.out.println("Nama = "+mahasiswaData.getData().get(0).getNama());
			System.out.println("Jenis Kelamin = "+mahasiswaData.getData().get(0).getJK());
			System.out.println("Tempat Lahir = "+mahasiswaData.getData().get(0).getTmpLahir());
			System.out.println("Tanggal Lahir = "+mahasiswaData.getData().get(0).getTglLahir());
			System.out.println("Alamat = "+mahasiswaData.getData().get(0).getAlamat());
		
		System.out.println(" ");
		System.out.println("Database Baris Ke-2");
		
			System.out.println("NIM = "+mahasiswaData.getData().get(1).getNim());
			System.out.println("Nama = "+mahasiswaData.getData().get(1).getNama());
			System.out.println("Jenis Kelamin = "+mahasiswaData.getData().get(1).getJK());
			System.out.println("Tempat Lahir = "+mahasiswaData.getData().get(1).getTmpLahir());
			System.out.println("Tanggal Lahir = "+mahasiswaData.getData().get(1).getTglLahir());
			System.out.println("Alamat = "+mahasiswaData.getData().get(1).getAlamat());
		
		
			
		}
	}

