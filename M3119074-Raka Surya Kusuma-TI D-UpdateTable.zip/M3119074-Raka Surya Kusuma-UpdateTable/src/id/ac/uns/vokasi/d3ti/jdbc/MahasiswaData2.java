package id.ac.uns.vokasi.d3ti.jdbc;


import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;

public class MahasiswaData2 {
	Connection con;
	Statement st;
	ResultSet rs;
	ArrayList <MahasiswaModel2> dataMahasiswa;
	
	public MahasiswaData2() {
		dataMahasiswa=new ArrayList<MahasiswaModel2>();
		try {
			String server="jdbc:mysql://127.0.0.1/pbolanjut?user=root&password=";
			Class.forName("com.mysql.jdbc.Driver");
			con=(Connection) DriverManager.getConnection(server);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public ArrayList<MahasiswaModel2> getData(){
		try {
			st=(Statement) con.createStatement();
			String query="SELECT * FROM mahasiswa";
			rs=(ResultSet) st.executeQuery(query);
			while(rs.next()) {
				MahasiswaModel2 mm=new MahasiswaModel2();
				mm.setNim(rs.getString(1));
				mm.setPass(rs.getString(2));
				mm.setNama(rs.getString(3));
				mm.setEmail(rs.getString(4));
				mm.setJk(rs.getString(5));
				dataMahasiswa.add(mm);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return dataMahasiswa;
	}
	
	public ArrayList<MahasiswaModel2> getRowNimData(String nim){
		try {
			st=(Statement) con.createStatement();
			String query="SELECT * FROM mahasiswa WHERE nim='"+nim+"'";
			rs=(ResultSet) st.executeQuery(query);
			while(rs.next()) {
				MahasiswaModel2 mm=new MahasiswaModel2();
				mm.setNim(rs.getString(1));
				mm.setPass(rs.getString(2));
				mm.setNama(rs.getString(3));
				mm.setEmail(rs.getString(4));
				mm.setJk(rs.getString(5));
				dataMahasiswa.add(mm);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return dataMahasiswa;
	}
	
	public void insertMahasiswa(String nim, String pass, String nama, String email, String jk) {
		try {
			st=(Statement) con.createStatement();
			String query="INSERT INTO mahasiswa(nim, pass, nama, email, jk)VALUES('"+nim+"','"+pass+"','"+nama+"','"+email+"','"+jk+"')";
			st.execute(query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void updateMahasiswa(String nim, String pass, String nama, String email, String jk) {
		try {
			st=(Statement) con.createStatement();
			String query="UPDATE mahasiswa SET nim='"+nim+"', pass='"+pass+"', nama='"+nama+"', email='"+email+"', jk='"+jk+"' WHERE nim='"+nim+"'";
			st.execute(query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void deleteMahasiswa(String nim) {
		try {
			st=(Statement) con.createStatement();
			String query="DELETE FROM mahasiswa SET WHERE nim='"+nim+"'";
			st.execute(query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}//end of class
