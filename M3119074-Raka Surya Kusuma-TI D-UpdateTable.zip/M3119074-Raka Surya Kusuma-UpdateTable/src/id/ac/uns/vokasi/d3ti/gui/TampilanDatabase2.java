package id.ac.uns.vokasi.d3ti.gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import id.ac.uns.vokasi.d3ti.jdbc.*;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TampilanDatabase2 extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private MahasiswaData2 mahasiswaData2;
	private JButton btnNewButton;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TampilanDatabase frame = new TampilanDatabase();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TampilanDatabase2 () {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 823, 568);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 96, 787, 375);
		contentPane.add(scrollPane);
		String[] columnName= {"NIM","Nama","Email","Password","Gender"};
		DefaultTableModel dtm=new DefaultTableModel();
		dtm.setColumnIdentifiers(columnName);
		
		mahasiswaData2=new MahasiswaData2();
		ArrayList<MahasiswaModel2> dataMahasiswa=new ArrayList<>();
		dataMahasiswa=mahasiswaData2.getData();
		for(int i=0;i<dataMahasiswa.size();i++) {
			ArrayList<Object> tempMhs=new ArrayList<>();
			tempMhs.add(dataMahasiswa.get(i).getNim());
			tempMhs.add(dataMahasiswa.get(i).getNama());
			tempMhs.add(dataMahasiswa.get(i).getEmail());
			tempMhs.add(dataMahasiswa.get(i).getPass());
			tempMhs.add(dataMahasiswa.get(i).getJk());
			dtm.addRow(tempMhs.toArray());
		}
		
		
		table = new JTable(dtm);
		scrollPane.setViewportView(table);
		
		btnNewButton = new JButton("Edit Data");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ConfirmEdit ce=new ConfirmEdit();
				ce.setVisible(true);
			}
		});
		btnNewButton.setBounds(358, 495, 89, 23);
		contentPane.add(btnNewButton);
	}
}
