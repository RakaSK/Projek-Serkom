<!DOCTYPE html>
<html lang="en">
<!-- VIEW -->

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Belajar OOP MVC</title>
</head>

<body bgcolor='white'>
    <?php
    echo $data;
    if ($opsi = 'jadwal') {
    ?><a href="inputJadwal.php">Tambah Jadwal</><?php
                                                } else {
                                                    ?><a href="inputData.php">Tambah Data</><?php
                                                }
                                                ?>
            <!-- <a href="inputJadwal.php">Tambah Jadwal</> -->
            <!-- <a href="inputData.php">Tambah Data</> -->

</body>

</html>