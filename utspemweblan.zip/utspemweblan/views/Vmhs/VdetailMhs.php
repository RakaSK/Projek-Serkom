<!DOCTYPE html>
<html lang="en">
<!-- VIEW -->

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Belajar OOP MVC</title>
</head>

<body bgcolor='white'>
    <!-- <img src="views/Vmhs/mhs.png" width="200" height="200"></img> -->
    <ul class="list-group">
        <li class="list-group-item active" aria-current="true">Detail KA</li>
        <li class="list-group-item"><?= $data ?></li>
    </ul>
    <a href="inputFormMhs.php">Tambah Data</>
</body>

</html>