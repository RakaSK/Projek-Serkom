<?php
require('controllers/CKA.php');
$mhs = new CKA();
$mhs->inputJadwalKA();
