package id.ac.uns.vokasi.d3ti.jdbc;

//mengecek apakah data database sudah bisa diambil atau belum

public class Mahasiswa {
	public static void main(String[] ar) {
		MahasiswaData mahasiswaData=new MahasiswaData();
		System.out.println(mahasiswaData.getData().get(0).getNim());
		
	}

}
