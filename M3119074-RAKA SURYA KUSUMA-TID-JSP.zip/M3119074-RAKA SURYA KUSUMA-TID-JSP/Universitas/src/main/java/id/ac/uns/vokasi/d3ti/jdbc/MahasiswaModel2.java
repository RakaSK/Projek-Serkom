package id.ac.uns.vokasi.d3ti.jdbc;

public class MahasiswaModel2 {
	String nim, pass, nama, email, jk;
	
	public void setNim(String nim) {
		this.nim=nim;
	}
	public void setPass(String pass) {
		this.pass=pass;
	}
	public void setNama(String nama) {
		this.nama=nama;
	}
	public void setEmail(String email) {
		this.email=email;
	}
	public void setJk(String jk) {
		this.jk=jk;
	}
	
	public String getNim() {
		return nim;
	}
	public String getPass() {
		return pass;
	}
	public String getNama() {
		return nama;
	}
	public String getEmail() {
		return email;
	}
	public String getJk() {
		return jk;
	}
}//end of class