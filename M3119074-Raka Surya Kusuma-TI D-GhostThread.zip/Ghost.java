package id.ac.uns.vokasi.d3ti.applet;

import java.awt.Image;
import java.net.URL;
import java.util.Random;

public class Ghost implements Runnable{
	
	int x,y;
	Image img;
	MateriPertama materiPertama;
	
	public Ghost(MateriPertama mp, URL p, String img) {
		materiPertama=mp;
		y=10;
		x=mp.getWidth()/2;
		this.img=mp.getImage(p,img);
		
		
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		boolean flagKiri=true;
		boolean flagAtas=true;
		
		while(y>0) {
			try {
				Thread.sleep(500);
				if(x>=400) {
					flagKiri=true;
				}
				if(y>=360) {
					flagAtas=true;
				}
				if(x<400) {
					flagKiri=false;
				}
				if(y<11) {
					flagAtas=false;
				}
				if(flagAtas) {
					y=y-10;
					if(flagKiri) {
						x=x-20;
					}
					if(flagKiri==false) {
						x=x+20;
					}
				}
				if(flagAtas==false) {
					y=y+10;
					if(flagKiri) {
						x=x-20;
					}
					if(flagKiri==false) {
						x=x+20;
					}
				}
				
				materiPertama.repaint();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		}
		
		
}//end of run method
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
	
	public Image getImg() {
		return img;
	}
	
	public void setY(int y) {
		this.y=y;
	}
	
	public void setX(int x) {
		this.x=x;
	}
	
}//end of class






